$(function(){
	$('#card1').addClass('move-scale');
	$('#card2').addClass('rotate-right');
});