$(function(){
	$('#racketA').css("top", "20px");
	$('#racketB').css("top", "60px");
});